"use strict";

(() => {
  if (window.__siteAudioRecorderInstallerLoaded) return;
  window.__siteAudioRecorderInstallerLoaded = true;

  const TARGET_SELECTOR = 'button[aria-label="Playbar: Toggle repeat button"]';
  const DOWNLOAD_BUTTON_SELECTOR = "button[data-site-audio-download]";
  const RECORDER_KEY = "__siteAudioRecorder";
  const TOAST_ID = "__siteAudioRecorderToast";
  const TOAST_FONT_STYLE_ID = "__siteAudioRecorderToastFont";

  function findPlayingAudio() {
    return Array.from(document.querySelectorAll("audio"))
      .find((audio) => !audio.paused && !audio.ended) || null;
  }

  function safeName(value) {
    return String(value || "site-audio")
      .replace(/[\\/:*?"<>|\u0000-\u001f]/g, "_")
      .replace(/^\.+/, "")
      .trim()
      .slice(0, 100) || "site-audio";
  }

  function ensureToastFont() {
    if (document.getElementById(TOAST_FONT_STYLE_ID)) return;

    const getUrl = globalThis.chrome?.runtime?.getURL;
    if (typeof getUrl !== "function") return;

    const style = document.createElement("style");
    style.id = TOAST_FONT_STYLE_ID;
    style.textContent = `@font-face {
      font-family: "Vazirmatn";
      src: url("${getUrl.call(globalThis.chrome.runtime, "fonts/Vazirmatn-wght.woff2")}") format("woff2");
      font-style: normal;
      font-weight: 100 900;
      font-display: swap;
    }`;
    (document.head || document.documentElement).appendChild(style);
  }

  function showToast(message, kind = "info", downloadUrl = "", filename = "") {
    ensureToastFont();
    let toast = document.getElementById(TOAST_ID);
    if (!toast) {
      toast = document.createElement("div");
      toast.id = TOAST_ID;
      toast.setAttribute("role", "status");
      Object.assign(toast.style, {
        position: "fixed",
        right: "16px",
        bottom: "16px",
        zIndex: "2147483647",
        maxWidth: "min(360px, calc(100vw - 32px))",
        padding: "12px 42px 12px 14px",
        borderRadius: "10px",
        background: "#f97316",
        color: "#2b1302",
        border: "1px solid rgba(255,255,255,.45)",
        boxShadow: "0 8px 30px rgba(194,65,12,.30)",
        font: "14px/1.65 Vazirmatn, Tahoma, sans-serif",
        direction: "rtl",
        textAlign: "right",
      });
      document.documentElement.appendChild(toast);
    }

    toast.textContent = "";
    const text = document.createElement("span");
    text.textContent = message;
    toast.appendChild(text);

    const closeButton = document.createElement("button");
    closeButton.type = "button";
    closeButton.setAttribute("aria-label", "بستن پیام");
    closeButton.title = "بستن";
    closeButton.textContent = "×";
    Object.assign(closeButton.style, {
      position: "absolute",
      top: "5px",
      right: "6px",
      width: "27px",
      height: "27px",
      display: "grid",
      placeItems: "center",
      padding: "0",
      border: "0",
      borderRadius: "8px",
      background: "rgba(255,255,255,.24)",
      color: "inherit",
      font: "700 21px/1 Tahoma, sans-serif",
      cursor: "pointer",
    });
    closeButton.addEventListener("click", () => {
      clearTimeout(toast.__hideTimer);
      toast.remove();
    });
    toast.appendChild(closeButton);

    if (downloadUrl) {
      const link = document.createElement("a");
      link.href = downloadUrl;
      link.download = filename || "site-audio.mp3";
      link.textContent = "دانلود فایل";
      Object.assign(link.style, {
        color: "#3b1d00",
        display: "inline-block",
        marginInlineStart: "10px",
        fontWeight: "700",
        fontFamily: "inherit",
      });
      toast.appendChild(link);
    }

    toast.dataset.kind = kind;
    clearTimeout(toast.__hideTimer);
    toast.__hideTimer = setTimeout(() => {
      toast.remove();
    }, downloadUrl ? 60_000 : 5000);
  }

  function setRecordingAppearance(button, recording) {
    if (!button) return;
    button.dataset.recording = recording ? "true" : "false";
    button.setAttribute(
      "aria-label",
      recording ? "Stop and download site audio" : "Download site audio from start"
    );
    button.title = recording ? "توقف و ذخیرهٔ صوت" : "ضبط صوت از ابتدا";

    const content = button.querySelector(".hxc-btn-content");
    if (!content) return;
    content.innerHTML = recording
      ? '<svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M7 7h10v10H7z"/></svg>'
      : '<svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M11 3h2v10.17l3.59-3.58L18 11l-6 6-6-6 1.41-1.41L11 13.17zM5 19h14v2H5z"/></svg>';
  }

  function stopRecording() {
    const state = window[RECORDER_KEY];
    if (!state?.recorder || state.recorder.state === "inactive") {
      return false;
    }
    if (state.stopping) return true;
    state.stopping = true;
    state.recorder.stop();
    return true;
  }

  function startRecording(audio, button) {
    const previous = window[RECORDER_KEY];
    if (previous?.recorder?.state === "recording") {
      showToast("ضبط از قبل در حال انجام است.", "warn");
      return;
    }

    if (typeof audio.captureStream !== "function") {
      showToast("این مرورگر ضبط مستقیم از پخش‌کننده را پشتیبانی نمی‌کند.", "error");
      return;
    }

    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (typeof AudioContextClass !== "function") {
      showToast("Web Audio در این مرورگر پشتیبانی نمی‌شود.", "error");
      return;
    }

    if (typeof lamejs === "undefined" || typeof lamejs.Mp3Encoder !== "function") {
      showToast("رمزگذار MP3 افزونه بارگذاری نشده است؛ افزونه را Reload کنید.", "error");
      return;
    }

    let stream;
    try {
      stream = audio.captureStream();
    } catch {
      showToast("گرفتن خروجی صوت ممکن نشد.", "error");
      return;
    }

    if (!stream.getAudioTracks().length) {
      showToast("از این پخش‌کننده مسیر صوتی دریافت نشد.", "error");
      return;
    }

    let audioContext;
    let source;
    let processor;
    let silentGain;
    try {
      audioContext = new AudioContextClass();
      source = audioContext.createMediaStreamSource(stream);
      const settings = stream.getAudioTracks()[0].getSettings?.() || {};
      const channels = Math.min(2, Math.max(1, Number(settings.channelCount) || 2));
      processor = audioContext.createScriptProcessor(4096, channels, channels);
      silentGain = audioContext.createGain();
      silentGain.gain.value = 0;
      source.connect(processor);
      processor.connect(silentGain);
      silentGain.connect(audioContext.destination);

      const encoder = new lamejs.Mp3Encoder(channels, audioContext.sampleRate, 128);
      const mp3Chunks = [];
      let state;
      const recorder = {
        state: "inactive",
        stop() {
          if (recorder.state !== "recording") return;
          recorder.state = "stopping";
          if (state) state.stopping = true;
          finishRecording();
        },
      };

      const toInt16 = (samples) => {
        const output = new Int16Array(samples.length);
        for (let index = 0; index < samples.length; index += 1) {
          const sample = Math.max(-1, Math.min(1, samples[index]));
          output[index] = sample < 0 ? sample * 0x8000 : sample * 0x7fff;
        }
        return output;
      };

      processor.onaudioprocess = (event) => {
        if (recorder.state !== "recording") return;
        const input = event.inputBuffer;
        const left = toInt16(input.getChannelData(0));
        const right = input.numberOfChannels > 1
          ? toInt16(input.getChannelData(1))
          : left;
        const encoded = channels === 1
          ? encoder.encodeBuffer(left)
          : encoder.encodeBuffer(left, right);
        if (encoded.length) mp3Chunks.push(encoded);
      };

      const title = safeName(
        audio.getAttribute("data-title") ||
        audio.getAttribute("aria-label") ||
        document.title
      );

      state = {
        recorder,
        stream,
        audioContext,
        source,
        processor,
        silentGain,
        encoder,
        mp3Chunks,
        title,
        button,
        stopping: false,
        startedAt: null,
      };
      window[RECORDER_KEY] = state;
      setRecordingAppearance(button, true);

      function finishRecording() {
        if (state.finishStarted) return;
        state.finishStarted = true;

        try {
          processor.onaudioprocess = null;
          source.disconnect();
          processor.disconnect();
          silentGain.disconnect();
          const tail = encoder.flush();
          if (tail.length) mp3Chunks.push(tail);

          const blob = new Blob(mp3Chunks, { type: "audio/mpeg" });
          if (!blob.size) throw new Error("empty_recording");

          const url = URL.createObjectURL(blob);
          const filename = `${title}.mp3`;
          const link = document.createElement("a");
          link.href = url;
          link.download = filename;
          link.style.display = "none";
          document.body.appendChild(link);
          link.click();
          link.remove();

          showToast("فایل MP3 آماده و ذخیره شد.", "ok", url, filename);
          setTimeout(() => URL.revokeObjectURL(url), 60_000);
        } catch {
          state.lastError = "save_failed";
          showToast("تبدیل یا ذخیرهٔ فایل MP3 ناموفق بود.", "error");
        } finally {
          stream.getTracks().forEach((track) => track.stop());
          mp3Chunks.length = 0;
          state.startedAt = null;
          state.stopping = false;
          state.state = "inactive";
          recorder.state = "inactive";
          setRecordingAppearance(button, false);
          window[RECORDER_KEY] = state;
          if (audioContext.state !== "closed") audioContext.close().catch(() => {});
        }
      }

      audio.addEventListener("ended", () => {
        if (recorder.state === "recording") recorder.stop();
      }, { once: true });

      recorder.state = "recording";
      state.startedAt = Date.now();
      audio.pause();
      audio.currentTime = 0;
      audioContext.resume().catch(() => {});
      const playPromise = audio.play();
      if (playPromise?.catch) {
        playPromise.catch(() => {
          state.lastError = "play_failed";
          if (recorder.state === "recording") recorder.stop();
          showToast("پخش صوت اجازه داده نشد.", "error");
        });
      }
      showToast("پخش از ابتدا شروع شد و ضبط MP3 در حال انجام است.", "ok");
      return;
    } catch {
      stream.getTracks().forEach((track) => track.stop());
      audioContext?.close?.().catch?.(() => {});
      showToast("راه‌اندازی ضبط MP3 ناموفق بود.", "error");
      return;
    }
  }

  function handlePendingPlay(event) {
    const audio = event.target;
    if (!audio || audio.tagName !== "AUDIO") return;

    const state = window[RECORDER_KEY];
    if (!state?.pending) return;

    // Prefer the audio element selected when the user pressed Start. If the
    // site rerendered that element, accept the next audio element that plays.
    if (state.pendingAudio && state.pendingAudio.isConnected && state.pendingAudio !== audio) {
      return;
    }

    state.pending = false;
    const button = state.button || document.querySelector(DOWNLOAD_BUTTON_SELECTOR);
    startRecording(audio, button || null);
  }

  function handleClick(event) {
    event.preventDefault();
    event.stopPropagation();

    const button = event.currentTarget;
    const state = window[RECORDER_KEY];
    if (state?.recorder?.state === "recording") {
      stopRecording();
      return;
    }

    const audio = findPlayingAudio() || document.querySelector("audio");
    if (!audio) {
      showToast("عنصر صوتی در صفحه پیدا نشد.", "error");
      return;
    }
    startRecording(audio, button);
  }

  function installButton() {
    const target = document.querySelector(TARGET_SELECTOR);
    if (!target || !target.parentElement) return;

    const next = target.nextElementSibling;
    if (next?.matches(DOWNLOAD_BUTTON_SELECTOR)) return;
    if (target.parentElement.querySelector(DOWNLOAD_BUTTON_SELECTOR)) return;

    const button = target.cloneNode(true);
    button.id = "site-audio-download-button";
    button.removeAttribute("data-inactive");
    button.setAttribute("data-site-audio-download", "true");
    button.setAttribute("type", "button");
    button.addEventListener("click", handleClick, true);
    setRecordingAppearance(button, false);
    target.insertAdjacentElement("afterend", button);
  }

  document.addEventListener("play", handlePendingPlay, true);
  window.__siteAudioRecorderShowToast = showToast;

  const observer = new MutationObserver(installButton);
  observer.observe(document.documentElement, { childList: true, subtree: true });
  installButton();
  setInterval(installButton, 1500);
})();
