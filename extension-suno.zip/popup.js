"use strict";

const els = {
  title: document.getElementById("title"),
  permission: document.getElementById("permission"),
  themeToggle: document.getElementById("theme-toggle"),
  download: document.getElementById("download"),
  progressWrap: document.getElementById("progress-wrap"),
  progress: document.getElementById("progress"),
  recordingTime: document.getElementById("recording-time"),
  status: document.getElementById("status"),
};

let activeTabId = null;
let refreshTimer = null;
let recordingTimer = null;
let recordingTimerStartedAt = null;

const MOON_ICON = '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M20.5 15.2A8.5 8.5 0 0 1 8.8 3.5 8.5 8.5 0 1 0 20.5 15.2Z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>';
const SUN_ICON = '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="3.5" stroke="currentColor" stroke-width="1.8"/><path d="M12 2v2m0 16v2M4.93 4.93l1.41 1.41m11.32 11.32 1.41 1.41M2 12h2m16 0h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>';
const DOWNLOAD_ICON = '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 3v11m0 0 4-4m-4 4-4-4M5 19h14" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const PLAY_ICON = '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m9 5 10 7-10 7V5Z" stroke="currentColor" stroke-width="1.9" stroke-linejoin="round"/></svg>';
const STOP_ICON = '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M7 7h10v10H7z" stroke="currentColor" stroke-width="1.9" stroke-linejoin="round"/></svg>';

function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  localStorage.setItem("site-audio-theme", theme);
  if (!els.themeToggle) return;
  const dark = theme === "dark";
  els.themeToggle.innerHTML = dark ? SUN_ICON : MOON_ICON;
  els.themeToggle.setAttribute("aria-label", dark ? "فعال‌کردن تم روشن" : "فعال‌کردن تم تیره");
  els.themeToggle.title = dark ? "تم روشن" : "تم تیره";
}

function initTheme() {
  const saved = localStorage.getItem("site-audio-theme");
  const prefersDark = typeof window.matchMedia === "function" &&
    window.matchMedia("(prefers-color-scheme: dark)").matches;
  const initial = saved === "light" || saved === "dark"
    ? saved
    : (prefersDark ? "dark" : "light");
  applyTheme(initial);
  els.themeToggle?.addEventListener("click", () => {
    applyTheme(document.documentElement.dataset.theme === "dark" ? "light" : "dark");
  });
}

function setStatus(text, kind = "") {
  els.status.textContent = text || "";
  els.status.className = "status " + kind;
}

function setSourceBadge() {
  els.permission.textContent = "فقط صوت همین صفحه";
  els.permission.className = "badge badge-ok";
}

function setButtons(recordingState) {
  const recording = recordingState === "recording";
  const stopping = recordingState === "stopping";
  const waiting = recordingState === "waiting";

  // One button is used as a stateful toggle: start -> stop and save.
  els.download.disabled = stopping;
  els.download.setAttribute("aria-pressed", recording ? "true" : "false");
  els.download.setAttribute(
    "aria-label",
    recording
      ? "توقف و ذخیره"
      : waiting
        ? "لغو انتظار پخش"
        : stopping
          ? "در حال ذخیره"
          : "شروع ضبط"
  );
  els.download.title = recording
    ? "توقف و ذخیره"
    : waiting
      ? "لغو انتظار پخش"
      : "شروع ضبط";
  els.download.classList.toggle("is-recording", recording);
  els.download.innerHTML = `${recording ? STOP_ICON : waiting ? PLAY_ICON : DOWNLOAD_ICON}<span>${
    recording
      ? "توقف و ذخیره"
      : waiting
        ? "منتظر پخش…"
        : stopping
          ? "در حال ذخیره…"
          : "شروع ضبط"
  }</span>`;
}

function formatDuration(milliseconds) {
  const totalSeconds = Math.max(0, Math.floor(milliseconds / 1000));
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  const pad = (value) => String(value).padStart(2, "0");
  return hours > 0
    ? `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`
    : `${pad(minutes)}:${pad(seconds)}`;
}

function stopRecordingTimer() {
  if (recordingTimer) clearInterval(recordingTimer);
  recordingTimer = null;
  recordingTimerStartedAt = null;
  if (els.recordingTime) els.recordingTime.textContent = "00:00";
}

function syncRecordingTimer(startedAt) {
  const parsedStartedAt = Number(startedAt);
  if (!Number.isFinite(parsedStartedAt)) return;

  if (recordingTimerStartedAt !== parsedStartedAt) {
    if (recordingTimer) clearInterval(recordingTimer);
    recordingTimerStartedAt = parsedStartedAt;
    const update = () => {
      if (els.recordingTime) {
        els.recordingTime.textContent = formatDuration(Date.now() - parsedStartedAt);
      }
    };
    update();
    recordingTimer = setInterval(update, 250);
  }
}

function setIndeterminateProgress(visible, startedAt = null) {
  els.progressWrap.hidden = !visible;
  if (visible) {
    els.progress.removeAttribute("value");
    syncRecordingTimer(startedAt);
  } else {
    stopRecordingTimer();
  }
}

async function executeInTab(func, args = []) {
  if (activeTabId == null) throw new Error("تب فعال پیدا نشد");
  const [injection] = await chrome.scripting.executeScript({
    target: { tabId: activeTabId },
    func,
    args,
  });
  return injection?.result;
}

async function injectPageRecorder() {
  if (activeTabId == null) return false;
  try {
    await chrome.scripting.executeScript({
      target: { tabId: activeTabId },
      files: ["lame.min.js", "page-recorder.js"],
    });
    return true;
  } catch {
    return false;
  }
}

// Runs inside the active page's isolated world. It never asks for tab capture,
// microphone, desktop capture, or system audio. It only uses one <audio> element.
function readPageState() {
  const recorder = window.__siteAudioRecorder;
  const recordingState = recorder?.pending
    ? "waiting"
    : recorder?.state === "stopping" || recorder?.stopping
    ? "stopping"
    : recorder?.recorder?.state || recorder?.state || "inactive";
  const list = Array.from(document.querySelectorAll("audio"));
  const active = list.find((a) => !a.paused && !a.ended) || list[0] || null;
  const title =
    active?.getAttribute("data-title") ||
    active?.getAttribute("aria-label") ||
    recorder?.title ||
    document.title ||
    "صوت سایت";

  return {
    hasAudio: list.length > 0,
    found: Boolean(active),
    playing: Boolean(active && !active.paused && !active.ended),
    title,
    captureSupported: Boolean(active && typeof active.captureStream === "function"),
    recordingState,
    startedAt: Number.isFinite(recorder?.startedAt) ? recorder.startedAt : null,
    lastError: recorder?.lastError || "",
  };
}

function armPageRecording() {
  const old = window.__siteAudioRecorder;
  const oldState = old?.pending
    ? "waiting"
    : old?.state === "stopping" || old?.stopping
      ? "stopping"
      : old?.recorder?.state || old?.state || "inactive";

  if (oldState === "recording" || oldState === "stopping") {
    return { ok: false, code: "already_recording" };
  }
  if (oldState === "waiting") {
    return { ok: false, code: "already_waiting" };
  }

  const list = Array.from(document.querySelectorAll("audio"));
  const audio = list.find((a) => !a.paused && !a.ended) || list[0] || null;
  if (!audio) {
    return { ok: false, code: list.length ? "nothing_playing" : "no_audio" };
  }
  const AudioContextClass = window.AudioContext || window.webkitAudioContext;
  if (typeof AudioContextClass !== "function") {
    return { ok: false, code: "audio_context_unsupported" };
  }
  if (typeof lamejs === "undefined" || typeof lamejs.Mp3Encoder !== "function") {
    return { ok: false, code: "mp3_encoder_missing" };
  }
  if (typeof audio.captureStream !== "function") {
    return { ok: false, code: "capture_unsupported" };
  }

  const rawTitle =
    audio.getAttribute("data-title") ||
    audio.getAttribute("aria-label") ||
    document.title ||
    "site-audio";

  // Pause an already-playing item so the next user Play click is unambiguous.
  audio.pause();
  window.__siteAudioRecorder = {
    pending: true,
    pendingAudio: audio,
    title: String(rawTitle),
    startedAt: null,
    lastError: "",
  };

  const message = "افزونه آماده پخش صوت است؛ لطفاً روی پخش صوت بزنید تا ضبط از ابتدا شروع شود.";
  if (typeof window.__siteAudioRecorderShowToast === "function") {
    window.__siteAudioRecorderShowToast(message, "info");
  }

  return { ok: true, title: String(rawTitle) };
}

function cancelPendingPageRecording() {
  const state = window.__siteAudioRecorder;
  if (!state?.pending) return { ok: false, code: "not_waiting" };
  state.pending = false;
  state.pendingAudio = null;
  window.__siteAudioRecorder = null;
  if (typeof window.__siteAudioRecorderShowToast === "function") {
    window.__siteAudioRecorderShowToast("انتظار پخش لغو شد.", "info");
  }
  return { ok: true };
}

function stopPageRecording() {
  const state = window.__siteAudioRecorder;
  const recorder = state?.recorder;
  if (!recorder || recorder.state === "inactive") {
    return { ok: false, code: "not_recording" };
  }
  if (state.state === "stopping") return { ok: true, state: "stopping" };

  state.state = "stopping";
  recorder.stop();
  return { ok: true, state: "stopping" };
}

const ERROR_TEXT = {
  no_audio: "در این صفحه عنصر صوتی پیدا نشد.",
  nothing_playing: "ابتدا صوت را Play کنید.",
  capture_unsupported: "مرورگر اجازهٔ ضبط این پخش‌کننده را نمی‌دهد.",
  capture_failed: "گرفتن خروجی صوت ممکن نشد.",
  no_audio_track: "از این پخش‌کننده هیچ مسیر صوتی دریافت نشد.",
  audio_context_unsupported: "Web Audio در این مرورگر پشتیبانی نمی‌شود.",
  mp3_encoder_missing: "رمزگذار MP3 افزونه بارگذاری نشده است؛ افزونه را Reload کنید.",
  recording_start_failed: "شروع ضبط ناموفق بود.",
  play_failed: "پخش صوت اجازه داده نشد.",
  already_recording: "ضبط از قبل در حال انجام است.",
  already_waiting: "افزونه از قبل منتظر کلیک روی پخش صوت است.",
  not_waiting: "در حال انتظار برای پخش نیست.",
  not_recording: "ضبط فعالی وجود ندارد.",
  empty_recording: "فایل ضبط‌شده خالی بود.",
  save_failed: "ذخیرهٔ فایل ضبط‌شده ناموفق بود.",
  page_access: "خواندن صفحه ممکن نشد؛ صفحه را رفرش کنید.",
  unknown: "خطای ناشناخته.",
};

function showError(code) {
  setButtons("inactive");
  setIndeterminateProgress(false);
  setStatus(ERROR_TEXT[code] || ERROR_TEXT.unknown, "err");
}

async function refresh() {
  if (activeTabId == null) return;

  let state;
  try {
    state = await executeInTab(readPageState);
  } catch {
    els.title.textContent = "—";
    setButtons("inactive");
    setStatus(ERROR_TEXT.page_access, "err");
    return;
  }

  if (!state) {
    showError("page_access");
    return;
  }

  setSourceBadge();
  els.title.textContent = state.title || "صوت سایت";

  if (state.recordingState === "waiting") {
    setButtons("waiting");
    setIndeterminateProgress(false);
    setStatus(
      "افزونه آماده پخش صوت است؛ لطفاً روی پخش صوت بزنید تا ضبط از ابتدا شروع شود.",
      "ok"
    );
    return;
  }

  if (state.recordingState === "recording" || state.recordingState === "stopping") {
    setButtons(state.recordingState);
    setIndeterminateProgress(true, state.startedAt);
    setStatus(
      state.recordingState === "stopping"
        ? "فایل در حال آماده‌سازی است…"
        : "فقط صدای همین پخش‌کننده در حال ضبط است.",
      "ok"
    );
    return;
  }

  setButtons("inactive");
  setIndeterminateProgress(false);

  if (state.lastError) {
    setStatus(ERROR_TEXT[state.lastError] || state.lastError, "err");
  } else if (!state.hasAudio) {
    setStatus(ERROR_TEXT.no_audio, "warn");
  } else if (!state.captureSupported) {
    setStatus(ERROR_TEXT.capture_unsupported, "err");
  } else if (!state.playing) {
    setStatus("آماده است؛ با شروع ضبط، صوت از ابتدا پخش می‌شود.", "ok");
  } else {
    setStatus("آمادهٔ ضبط صوت همین صفحه.", "ok");
  }

  els.download.disabled = !state.found || !state.captureSupported;
}

els.download.addEventListener("click", async () => {
  let pageState;
  try {
    pageState = await executeInTab(readPageState);
  } catch {
    showError("page_access");
    return;
  }

  if (pageState?.recordingState === "recording") {
    setButtons("stopping");
    setStatus("فایل در حال آماده‌سازی و ذخیره است…", "ok");
    try {
      const result = await executeInTab(stopPageRecording);
      if (!result?.ok) showError(result?.code || "not_recording");
    } catch {
      showError("page_access");
    }
    return;
  }

  if (pageState?.recordingState === "waiting") {
    try {
      const result = await executeInTab(cancelPendingPageRecording);
      if (!result?.ok) {
        showError(result?.code || "not_waiting");
        return;
      }
      await refresh();
    } catch {
      showError("page_access");
    }
    return;
  }

  if (pageState?.recordingState === "stopping") return;

  setButtons("waiting");
  setIndeterminateProgress(false);
  setStatus(
    "افزونه آماده پخش صوت است؛ لطفاً روی پخش صوت بزنید تا ضبط از ابتدا شروع شود.",
    "ok"
  );

  try {
    const result = await executeInTab(armPageRecording);
    if (!result?.ok) {
      showError(result?.code || "unknown");
      return;
    }
    await refresh();
  } catch {
    showError("page_access");
  }
});

async function init() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  activeTabId = tab?.id ?? null;

  let url;
  try {
    url = new URL(tab?.url || "");
  } catch {
    url = null;
  }

  if (!tab || !url || !["http:", "https:"].includes(url.protocol)) {
    els.title.textContent = "—";
    setButtons("inactive");
    setStatus("این افزونه فقط روی صفحهٔ سایت اجرا می‌شود.", "warn");
    return;
  }

  // This also fixes pages that were already open before the extension was
  // installed/reloaded, or whose hostname is not covered by content_scripts.
  await injectPageRecorder();
  await refresh();
  refreshTimer = setInterval(refresh, 1000);
}

window.addEventListener("unload", () => {
  if (refreshTimer) clearInterval(refreshTimer);
  stopRecordingTimer();
});

initTheme();
init();
