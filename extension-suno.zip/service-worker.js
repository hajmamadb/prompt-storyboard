"use strict";

const TRACK_ID_RE = /^[A-Za-z0-9_-]{1,128}$/;
const FETCH_TIMEOUT_MS = 15000;

class DownloadError extends Error {
  constructor(code) {
    super(code);
    this.code = code;
  }
}

function sanitizeFilename(name, mimeType) {
  let base = String(name || "").replace(/[\\/:*?"<>|\u0000-\u001f]/g, "_").replace(/^\.+/, "").trim();
  base = base.slice(0, 120);
  if (!base) base = "track";
  if (!/\.[A-Za-z0-9]{2,5}$/.test(base)) {
    const ext = { "audio/mp4": "m4a", "audio/mpeg": "mp3", "audio/ogg": "ogg", "audio/flac": "flac", "audio/wav": "wav" }[mimeType] || "m4a";
    base += "." + ext;
  }
  return base;
}

function parseOrigin(raw) {
  let u;
  try { u = new URL(raw); } catch { throw new DownloadError("bad_origin"); }
  if (u.protocol !== "https:" || u.origin !== raw) throw new DownloadError("bad_origin");
  return u;
}

// The signed URL must be https and live on the page's own host or one of its subdomains
// (e.g. page www.example.com or example.com -> example.com, cdn.example.com).
function validateDownloadUrl(raw, pageHost) {
  let u;
  try { u = new URL(raw); } catch { throw new DownloadError("untrusted_url"); }
  const base = pageHost.replace(/^www\./, "");
  const hostOk = u.hostname === pageHost || u.hostname === base || u.hostname.endsWith("." + base);
  if (u.protocol !== "https:" || !hostOk || u.username || u.password) {
    throw new DownloadError("untrusted_url");
  }
  return u.toString();
}

async function fetchDownloadInfo(originRaw, trackId) {
  const page = parseOrigin(originRaw);
  if (!TRACK_ID_RE.test(trackId)) throw new DownloadError("invalid_track");
  const granted = await chrome.permissions.contains({ origins: [page.origin + "/*"] });
  if (!granted) throw new DownloadError("permission_needed");

  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), FETCH_TIMEOUT_MS);
  let resp;
  try {
    // The browser attaches the user's own session cookie; the extension never reads it.
    resp = await fetch(`${page.origin}/api/v1/tracks/${encodeURIComponent(trackId)}/download`, {
      method: "GET",
      credentials: "include",
      cache: "no-store",
      redirect: "error",
      headers: { Accept: "application/json" },
      signal: ctrl.signal,
    });
  } catch {
    throw new DownloadError("network");
  } finally {
    clearTimeout(timer);
  }

  if (resp.status === 401) throw new DownloadError("unauthorized");
  if (resp.status === 403) throw new DownloadError("download_not_allowed");
  if (resp.status === 404 || resp.status === 400) {
    // 404 may mean either an unknown track or a missing endpoint; the body tells which.
    const body = await resp.json().catch(() => null);
    throw new DownloadError(body && body.reason ? "invalid_track" : "endpoint_missing");
  }
  if (resp.status === 429) throw new DownloadError("rate_limited");
  if (!resp.ok) throw new DownloadError("bad_response");

  const data = await resp.json().catch(() => null);
  if (!data || typeof data !== "object") throw new DownloadError("bad_response");

  if (data.ok !== true) {
    if (data.reason === "download_not_allowed") throw new DownloadError("download_not_allowed");
    if (data.reason === "unauthorized") throw new DownloadError("unauthorized");
    throw new DownloadError("invalid_track");
  }

  if (typeof data.downloadUrl !== "string" || typeof data.filename !== "string") {
    throw new DownloadError("bad_response");
  }
  if (typeof data.mimeType !== "string" || !data.mimeType.startsWith("audio/")) {
    throw new DownloadError("bad_response");
  }
  if (data.expiresAt) {
    const exp = Date.parse(data.expiresAt);
    if (Number.isNaN(exp)) throw new DownloadError("bad_response");
    if (exp <= Date.now()) throw new DownloadError("url_expired");
  }

  return {
    url: validateDownloadUrl(data.downloadUrl, page.hostname), // never logged or stored
    filename: sanitizeFilename(data.filename, data.mimeType),
  };
}

async function startDownload(originRaw, trackId) {
  const info = await fetchDownloadInfo(originRaw, trackId);
  const downloadId = await new Promise((resolve, reject) => {
    chrome.downloads.download(
      { url: info.url, filename: info.filename, saveAs: false, conflictAction: "uniquify" },
      (id) => {
        if (chrome.runtime.lastError || id === undefined) {
          reject(new DownloadError("download_failed"));
        } else {
          resolve(id);
        }
      }
    );
  });
  return downloadId;
}

function notifyPopup(payload) {
  // The popup may be closed; ignore "no receiver" errors.
  chrome.runtime.sendMessage({ type: "DOWNLOAD_STATE", ...payload }).catch(() => {});
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // Accept messages only from this extension's own pages.
  if (sender.id !== chrome.runtime.id) return false;

  if (msg?.type === "START_DOWNLOAD") {
    startDownload(String(msg.origin || ""), String(msg.trackId || ""))
      .then((downloadId) => sendResponse({ ok: true, downloadId }))
      .catch((e) => sendResponse({ ok: false, error: e instanceof DownloadError ? e.code : "unknown" }));
    return true; // async response
  }

  if (msg?.type === "CANCEL_DOWNLOAD" && Number.isInteger(msg.downloadId)) {
    chrome.downloads.cancel(msg.downloadId).then(() => sendResponse({ ok: true })).catch(() => sendResponse({ ok: false }));
    return true;
  }
  return false;
});

chrome.downloads.onChanged.addListener(async (delta) => {
  // Only report downloads started by this extension (works even after a worker restart).
  const [item] = await chrome.downloads.search({ id: delta.id });
  if (!item || item.byExtensionId !== chrome.runtime.id) return;

  if (delta.state?.current === "complete") {
    notifyPopup({ downloadId: delta.id, state: "complete" });
    return;
  }
  if (delta.state?.current === "interrupted" || delta.error) {
    const reason = delta.error?.current || item.error;
    if (reason === "USER_CANCELED") {
      notifyPopup({ downloadId: delta.id, state: "cancelled" });
    } else {
      const expired = reason === "SERVER_FORBIDDEN" || reason === "SERVER_UNAUTHORIZED";
      notifyPopup({ downloadId: delta.id, state: "error", error: expired ? "url_expired" : "download_failed" });
    }
    return;
  }
  if (delta.bytesReceived || delta.totalBytes) {
    notifyPopup({ downloadId: delta.id, state: "progress", received: item.bytesReceived, total: item.totalBytes });
  }
});
